export default function page() {
  return (
    <div>
      <h1> This is Register page </h1>
    </div>
  );
}
