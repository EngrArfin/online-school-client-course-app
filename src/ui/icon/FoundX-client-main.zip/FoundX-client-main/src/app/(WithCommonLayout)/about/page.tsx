export default function page() {
  return (
    <div>
      <h1> This is About page </h1>
    </div>
  );
}
