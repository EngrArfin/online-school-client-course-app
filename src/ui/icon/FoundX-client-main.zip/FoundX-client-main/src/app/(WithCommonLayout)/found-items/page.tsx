export default function page() {
  return (
    <div>
      <h1> This is Found items page </h1>
    </div>
  );
}
