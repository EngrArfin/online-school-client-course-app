const envConfig = {
  baseApi: process.env.NEXT_PUBLIC_BASE_API,
};

export default envConfig;
